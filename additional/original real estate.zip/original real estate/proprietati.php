<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<style media="screen">

  .checkbox_main_div {
    display: flex;
    flex-direction: column;
    justify-content: flex-start;
    width: 100%;
  }

  .checbox_second_div {
    display: flex;
    flex-direction: row;
    justify-content: flex-start;
    column-gap: 5%;
    align-items: center;
  }

  input[type ="checkbox"], input[type='radio'] {
    height: 20px !important;
    width: 20px !important;
  }

  .spec-box > label {
    font-size: 18px !important;

  }
</style>
<style media="screen">
  .properties {
    flex-wrap: wrap;
    overflow: hidden !important;
  }

  .property{
      flex: 0 0 calc(50% - 30px) !important;
  }

  .prop_filter {
    display: flex;
    flex-direction: row-reverse;
  }

    .prop_filter > .properties {
      width: 66.66%;
    }

    .prop_filter > .filter {
      background-color: #ededed;
      overflow-y: scroll;
      height: 58.9%;
      width: 33.33%;
      padding: 8px 10px;
      box-shadow: rgba(0, 0, 0, 0.16) 0px 1px 4px;
      display: flex;
      flex-direction: column;
      justify-content: space-between;
    }

    .filter select, .filter input {
      padding: 10px;
      height: 50px;
      width: 100%;
    }

    .specifications {
      display: flex;
      flex-direction: column;
      justify-content: space-between;
      align-items: center;
    }

    .spec-box {
        width: 100%;
        display: flex;
        flex-direction: column;
        align-items: center;
        min-height: 70px;
        margin-bottom:20px;
    }
    /* .specifications {
      line-height: 40px;
    } */

    .spec-box > label {
      font-weight: bold;
      margin-bottom: 5px;
      margin-right: auto;
    }

    .button {
      display: flex;
      column-gap: 10px;
    }

    .reset {
      background-color: red !important;
    }

    .filter select {
      border: none;
      background-color: #fff;
      border-radius: 0;
      border-width: 0;

    }
</style>

<?php require_once('conf.php'); ?>
<?php
  $result = $mysql->query("SELECT * FROM `proprietati`");
  $title = 'Properties';
$tip_achizitie = $_GET['tip_achizitie'] ?? '';
$tip_imobil = $_GET['tip_imobil'] ?? '';
$oras = $_GET['oras'] ?? '';
$where = '';

if($tip_achizitie || $tip_imobil || $oras) {
  $title = 'Rezultatele cautarii:';
  $where = "WHERE";
}

if($tip_achizitie) $where .= " `tip_achizitie` = '$tip_achizitie' ";
if($tip_achizitie && $tip_imobil) $where .= 'AND';
if($tip_imobil) $where .= " `tip_imobil` = '$tip_imobil' ";
if(($tip_achizitie && $oras) || ($tip_imobil && $oras)) $where .= 'AND';
if($oras) $where .= " `oras` = '$oras' ";


 // var_dump("SELECT * FROM `proprietati` " . $where);
 // die();
$result = $mysql->query("SELECT * FROM `proprietati` " . $where);
?>
<?php require_once('header.php'); ?>

<div class="overlay">
       <a class="close">&times;</a>
         <div class="overlay__content">
           <a href="index.php">Acasă</a>
           <a href="proprietati.php">Real Estates</a>
           <a href="index.php#aboutus">About US</a>
           <a href="index.php#contacts">Contacts</a>
         </div>
     </div>

   <!--MENU BUTTON-->
    <section class="section-properties" id="properties">
        <div class="container">

            <h1 style="border-bottom: solid 2px #888888">All disponible real estates</h1>

            <?php if ($result->num_rows > 0): ?>
              <div class="prop_filter">
                <div class="filter">
                  <div class="specifications">
                    <div class="spec-box">
                      <label for="Sort">Sort by</label>
                      <select class="Sort" name="Sort">
                        <option value="New">What's new</option>
                        <option value="LtoH">Price: Low to High</option>
                        <option value="HtoL">Price: High to Low</option>
                      </select>
                    </div>
                    <div class="spec-box">
                      <label for="Offer">Type of purchased</label>
                      <select class="Offer" name="Offer">
                        <option value="">Rent</option>
                        <option value="">Sale</option>
                      </select>
                    </div>

                    <div class="spec-box">
                      <label for="Locality">Locality</label>
                      <select class="Locality" name="Locality">
                        <option value="">All</option>
                        <option value="">Funchal</option>
                        <option value="">Machico</option>
                        <option value="">Santana</option>
                        <option value="">Camara de Lobos</option>
                        <option value="">Santa Cruz</option>
                        <option value="">Porto Moniz</option>
                        <option value="">Calheta</option>
                        <option value="">Ponto do Sol</option>
                        <option value="">Sao Vicente</option>
                        <option value="">Ribeira Brava</option>
                        <option value="">Vila Baleira</option>
                        <option value="">Ribeiro Frio</option>
                      </select>
                    </div>
                    <div class="spec-box price-range-class">
                      <label for="price-range">Price</label>
                      <div class="price-range" name = "price-range">
                        <input type="number" name="" value="">
                        <b> - </b>
                        <input type="number" name="" value="">

                        <style media="screen">
                            .price-range {
                              display: flex;
                              flex-direction: row;
                              align-items: center;
                              justify-content: flex-end;
                            }
                        </style>
                      </div>
                    </div>
                    <div class="spec-box">
                      <label for="ToRE">Type of R.E.</label>
                      <select class="ToRE" name="ToRE">
                        <option value="">All</option>
                        <option value="">Apartments</option>
                        <option value="">Offices</option>
                        <option value="">Houses</option>
                        <option value="">Comercial spaces</option>
                      </select>
                    </div>
                    <div class="spec-box">
                      <label for="demension-range">Size:</label>
                      <div class="demension-range" name = "demension-range">
                        <input type="number" name="" value="">
                        <b> - </b>
                        <input type="number" name="" value="">

                        <style media="screen">
                            .price-range, .demension-range {
                              display: flex;
                              flex-direction: row;
                              align-items: center;
                              justify-content: flex-end;
                            }
                        </style>
                      </div>
                    </div>

                    <div class="spec-box">
                      <label for="Beddrooms">Beedrooms:</label>
                      <div class="checkbox_main_div" name = "Beedrooms">
                        <div class="checbox_second_div">
                          <input type="checkbox" id="T0" name="scales"  checked>
                          <label for="T0">T0</label>
                        </div>
                        <div class="checbox_second_div">
                          <input type="checkbox" id="T1" name="scales"  checked>
                          <label for="T1">T1</label>
                        </div>
                        <div class="checbox_second_div">
                          <input type="checkbox" id="T2" name="scales"  checked>
                          <label for="T2">T2</label>
                        </div>
                        <div class="checbox_second_div">
                          <input type="checkbox" id="T3" name="scales"  checked>
                          <label for="T3">T3</label>
                        </div>
                      </div>

                    </div>
                    <div class="spec-box">
                      <label for="Condition">Condition</label>
                      <div class="checkbox_main_div" name = "Condition">
                        <div class="checbox_second_div">
                          <input type="checkbox" id="New_homes" name="scales"  checked>
                          <label for="New_homes">New homes</label>
                        </div>
                        <div class="checbox_second_div">
                          <input type="checkbox" id="Good conditions" name="scales"  checked>
                          <label for="Good conditions">Good conditions</label>
                        </div>
                        <div class="checbox_second_div">
                          <input type="checkbox" id="Needs_renovating" name="scales"  checked>
                          <label for="Needs_renovating">Needs renovating</label>
                        </div>
                      </div>
                    </div>

                    <div class="spec-box">
                      <div class="spec-box">
                        <label for="Publication_date">Publication date</label>
                        <div class="checkbox_main_div" name = "Publication_date">
                          <div class="checbox_second_div">
                            <input type="radio" id="Indifferent" name="scales"  checked>
                            <label for="Indifferent">Indifferent</label>
                          </div>
                          <div class="checbox_second_div">
                            <input type="radio" id="Last 48 hours" name="scales"  checked>
                            <label for="Last 48 hours">Last 48 hours</label>
                          </div>
                          <div class="checbox_second_div">
                            <input type="radio" id="Last week" name="scales"  checked>
                            <label for="Last week">Last week</label>
                          </div>
		                       <div class="checbox_second_div">
                            <input type="radio" id="Last month" name="scales"  checked>
                            <label for="Last month">Last month</label>
                          </div>
                        </div>
                      </div>
                    </div>

                  </div>
                  <div class="button">
                    <button type="submit">Search</button>
                    <button type="submit" class = "reset">Reset</button>
                  </div>

                  <style media="screen">
                    .filter .button {
                      margin-top: 20px;
                    }
                  </style>
                </div>

                <div class="properties">

                <?php while( $row = $result->fetch_assoc() ): ?>
                  <div class="property">
                      <div class="property-image">
                          <a href="<?php echo 'property.php?id='.$row['id']; ?>">
                              <?php if($row['imagine_1']): ?>
                                  <img src="<?php echo $row['imagine_1']; ?>" />
                              <?php endif; ?>
                          </a>
                      </div>
                      <h5>
                          <a href="<?php echo 'property.php?id='.$row['id']; ?>">
                            <?php echo $row['titlu']; ?>
                          </a>
                      </h5>
                      <div class="property-options">
                          <ul>
                              <li>Suprafața totală</li>
                              <li><?php echo $row['suprafata']; ?> m<sup>2</sup></li>
                              <li><?php echo $row['camere']; ?> camere</li>
                              <li><?php echo $row['anul']; ?></li>
                          </ul>
                      </div>
                      <h6><?php echo $row['pret']; ?>$/lună</h6>
                  </div>
                <?php endwhile; ?>
                </div>

              <!-- </div> -->
            <?php else: ?>
                There are no properties!
            <?php endif; ?>
        </div>
    </section>
<?php require_once('footer.php'); ?>
<script type="text/javascript">
$( document ).ready(function() {
  // $(".spec-box").children().eq(1).css("width" : "'"+$(".spec-box").width()/2+"'");
  // $(".spec-box").children().eq(2).css("width" : "'"+$(".spec-box").width()/2+"'");
});
</script>
