<?php
include 'header.php';
?>
<!DOCTYPE html>
<html lang="ro" dir="ltr">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="icon" href="favicon.ico" type="image/x-icon"/>
    <title> Best Property </title>
    <link rel="stylesheet" href="styles/style.css">
    <link rel="stylesheet" href="styles/slick.css">
    <link rel="stylesheet" href="styles/slick-theme.css">
    <link rel="stylesheet"href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/css/all.min.css"/>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
</head>
<body>
<div class="overlay">
       <a class="close">&times;</a>
         <div class="overlay__content">
           <a href="index.php">Acasă</a>
           <a href="proprietati.php">Real Estates</a>
           <a href="index.php#aboutus">About US</a>
           <a href="index.php#contacts">Contacts</a>
         </div>
     </div>

   <!--MENU BUTTON-->

<section class="section-banner">
    <div class="container">
        <!-- <div class=""> -->
          <form id="search" action="proprietati.php" method="GET">
            <h1>Search your ideal variant</h1>
            <div class="form-field">
              <select name="tip_achizitie">
                <option value="Top">-Type of purchase-</option>
                <option value="To buy">Buy</option>
                <option value="To rent">Rent</option>
              </select>
            </div>
            <div class="form-field">
              <select name="tip_imobil">
                <option value="Tob">-Type of building-</option>
                <option value="Apartament">Apartment</option>
                <option value="Office">Office</option>
                <option value="House">House</option>
                <option value="Comercial space">Comercial space</option>
              </select>
            </div>
            <div class="form-field">
              <select name="oras">
                <?php
                include "conf.php";
                $result = $mysql->query("SELECT oras FROM proprietati group by oras;");
                while($option = $result->fetch_assoc())
                echo "
                <option value='".$option['oras']."'>".$option['oras']."</option>
                ";
                ?>
              </select>
            </div>
            <div class="form-field">
              <button type="submit">
                  <i class="fas fa-search"></i>
                  <p>Search</p>
              </button>
            </div>
            <h2 style="text-align:center; color:black;">OR</h2>
            <div class="form-field">
              <button type="submit">
                <i class="fas fa-plus"></i>
                <p>Add your offer</p>
                </button>
            </div>
          </form>
          <!-- <div class="">
            <h1>Add your offer!</h1>
            <button type="submit" name="button">Add</button>
          </div>
        </div> -->
    </div>
</section>
<!-- .section-banner -->

<?php $result = $mysql->query("SELECT * FROM `proprietati` "); ?>
<section class="section-properties" id="properties">
    <i class="fas fa-chevron-left"></i>
    <div class="container">
        <h1 style="border-bottom: solid 2px #888888;">Recent add</h1><?php if ($result->num_rows > 0): ?>
          <div class="properties">
            <?php while( $row = $result->fetch_assoc() ): ?>
              <div class="property">
                <div class="property-image">
                  <a href="<?php echo 'property.php?id='.$row['id']; ?>">
                    <?php if($row['imagine_1']): ?>
                      <img src="<?php echo $row['imagine_1']; ?>" />
                    <?php endif; ?>
                  </a>
                </div>
                <h5>
                  <a href="<?php echo 'property.php?id='.$row['id']; ?>">
                    <?php echo $row['titlu']; ?>
                  </a>
                </h5>
                <div class="property-options">
                  <ul>
                    <li>Suprafața totală</li>
                    <li><?php echo $row['suprafata']; ?> m<sup>2</sup></li>
                    <li><?php echo $row['camere']; ?> camere</li>
                    <li><?php echo $row['anul']; ?></li>
                  </ul>
                </div>
                <h6><?php echo $row['pret']; ?>$/lună</h6>
              </div>
            <?php endwhile; ?>
          </div>
        <?php else: ?>
          There are no properties!
        <?php endif; ?>

    </div>
    <i class="fas fa-chevron-right"></i>
</section>
<!-- .section-properties -->

<section class="section-testimonials" id="testimonials">
    <div class="container">
        <h1>Reviews</h1>
        <div class="testimonials ">
            <div class="testimonials-item">
                <div class="testimonials-thumbnail">
                    <img src="images/testimonial_1.jpg">
                </div>
                <h6 class="testimonials-title">Aurelia E. Bogza</h6>
                <div class="testimonials-position">CEO at Pixies Inc.</div>
                <div class="testimonials-description">
                    <p>
                        <em>I have been renting well properties through this company for over 5 years and have always been extremely happy with their work.
                        </em>
                    </p>
                </div>
            </div>

            <div class="testimonials-item">
                <div class="testimonials-thumbnail">
                    <img src="images/testimonial_2.jpg">
                </div>
                <h6 class="testimonials-title">Dumitru Costel</h6>
                <div class="testimonials-position">Manager of Leogrand.</div>

                <div class="testimonials-description">
                    <p>
                        <em>We were extremely impressed by the service offered by Best Property, they are very prompt and professional.
                        </em>
                    </p>
                </div>
            </div>

            <div class="testimonials-item">
                <div class="testimonials-thumbnail">
                    <img src="images/testimonial_3.jpg">
                </div>
                <h6 class="testimonials-title">Alexandra Ioana</h6>
                <div class="testimonials-position">Director at JustConsult.</div>

                <div class="testimonials-description">
                    <p><em>Thanks for everything. I have been renting through this agency for more than 5 years and have never had a problem with them.
                       </em>
                    </p>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- .section-testimonials -->

<section class="section-about" id="aboutus">
    <div class="container">
        <h1>About US</h1>
        <div class="about">
            <div class="about-image">
                <img src="images/about.jpg">
            </div>
            <div class="about-text">
              <h3>Best Property</h3>
              <h6>It was founded in Funchal as a company focused on efficiently satisfying customers and serving them at the highest quality in all real estate requests.</h6>
              <br>
              <p>Over time, the company dominates the real estate market in Portugal through customer orientation, providing both professional support and understanding of personal needs. As a result of working with people, our work has become a passion for each of us.</p>
              <p>The range of services provided by US is varied and complex, because we have the largest real estate database and we make maximum effort to achieve all customer needs.</p>
            </div>
        </div>
    </div>
</section>
<!-- .section-about -->

<section class="section-contact" id="contacts">
    <div class="container">
        <h1>Contacts</h1>
        <div class="contact">
            <div class="contact-text">
              <h3>Address from Funchal:</h3>
		            <h5>Estrada Monumental 455, 9000-098 Funchal, Portugal</h5>
              <p>
                 We want every customer to buy their dream home, for this reason we gather in our database the most advantageous real estate offers at affordable prices. We want to be recognized as a reliable partner that delivers professional real estate services, saving time, money and nerves to our clients.
              </p>
            </div>
            <div class="contact-form">
                <form id="contactus">
                    <div class="form-field">
                        <input type = "text" name="name" placeholder="Your name" required />
                    </div>
                    <div class="form-field">
                        <input type="email" name="email" placeholder="Email address" required />
                    </div>
                    <div class="form-field">
                      <textarea id = "message" name="message" placeholder="Message..."></textarea>
                    </div>
                    <div class="form-field">
                        <button type="submit" id= "contact_mail" name = "contact_mail">
                          <i class="fas fa-paper-plane"></i>
                          <p>Send</p>
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>
<script type="text/javascript">
$( document ).ready(function() {

  $(".fa-chevron-left").click(function() {
    $('.properties').animate({scrollLeft: '-=300px'}, 800);
  });
  $(".fa-chevron-right").click(function() {
    $('.properties').animate({scrollLeft: '+=300px'}, 800);
  });
  $( "#contact_mail" ).on( "click", function() {
    var name = $("input[name='name']").val();
    var email = $("input[name='email']").val();
    // var message = $("#message").val();
    if(name.length!=0 && email.length!=0 && message.length!=0) {
      $.ajax({
        type: "POST",
        url: "mail.php",
        data: {name: name, email: email, message: message, contact_mail: "1"},
        success: function(data)
        {
          $("input[name='name']").val(null);
          $("input[name='email']").val(null);
          // $("#message").val("Mesajul...");
        }
      });
    }
  });
});
</script>
<!-- .section-contact -->
<?php require_once('footer.php'); ?>
