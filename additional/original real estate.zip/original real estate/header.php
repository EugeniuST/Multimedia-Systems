<!DOCTYPE html>
<html lang="ro" dir="ltr">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="icon" href="favicon.ico" type="image/x-icon"/>
    <title> Best Property </title>
    <link rel="stylesheet" href="styles/style.css">
    <link rel="stylesheet" href="styles/slick.css">
    <link rel="stylesheet" href="styles/slick-theme.css">
    <link rel="stylesheet"href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/css/all.min.css"/>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
  <header id="header">
      <div class="container">
          <div class="header-left">
              <a href="index.php" title="Comercial agentse Imobiliara" class="logo">
                <style media="screen">
                  .icon > * {
                    color: #303441;
                  }

                  .icon {
                    display: flex;
                    flex-direction: row;
                    align-items: center;
                    column-gap: 5%;
                  }
                </style>
                <div class="icon">
                  <img style="width: 60px" src="images\bl1.png" alt="">
                  <h1 style="font-size:20px;padding: 0; margin:0">Best Property</h1>
                </div>
              </a>
          </div>

          <div class="header-right">
              <ul class="header-menu">
                  <li><a href="index.php">Home</a></li>
                  <li><a href="proprietati.php">Real Estates</a></li>
                  <li><a href="index.php#aboutus">About US</a></li>
                  <li><a href="index.php#contactus">Contacts</a></li>
              </ul>
              <button id="btn-menu" type="button">menu</button>
          </div>
      </div>
  </header>
