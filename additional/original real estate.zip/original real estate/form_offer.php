<html lang="ro" dir="ltr">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="icon" href="favicon.ico" type="image/x-icon"/>
    <title> Best Property </title>
    <link rel="stylesheet" href="styles/style.css">
    <link rel="stylesheet"href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/css/all.min.css"/>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
  </head>
  <body>
    <?php
    include 'header.php';
    ?>
    <section>

      <form class="filter container">
        <h1>Information about your offer:</h1>
        <div class="specifications">
          <div class="spec-box">
            <label for="ToB">Type of building</label>
            <select class="ToB" name="ToB">
              <option value="">Apartment</option>
            </select>
          </div>
          <div class="spec-box">
            <label for="Offer">Type of purchased</label>
            <select class="Offer" name="Offer">
              <option value="">To rent</option>
              <option value="">To buy</option>
            </select>
          </div>
          <div class="spec-box">
            <label for="Title">Ad Title</label>
            <input type="text" name="Title" value="">
          </div>
          <div class="spec-box">
            <label for="Text">Ad Text</label>
            <textarea name="Text" rows="8" cols="80"></textarea>
            <style media="screen">
            .spec-box textarea {
              resize: both;
              overflow: auto;
            }

            .flex_row_jstart {
              column-gap: 5%;
              width: 100%;
              display: flex;
              flex-direction: row;
              align-items: center;
              justify-content: flex-start;
            }

            .flex_column {
              display: flex;
              flex-direction: column;
              justify-content: center;
              margin-bottom: 10px;
              flex: 0 0 20%;
            }

            .wrap {
              flex-wrap: wrap;
            }
            </style>
          </div>

          <div class="spec-box">
            <div class="flex_row_jstart wrap" style="align-items:flex-end">
              <div class="flex_column">
                <label for="price">Price</label>
                <div class="flex_row_jstart">
                  <input type="number" name="" value="">
                  <i class="fas fa-euro-sign"></i>
                </div>
                <style media="screen">
                </style>
              </div>
              <div class="flex_column">
                <label for="Trance">Trance payment?</label>
                <div class="flex_column">
                  <div class="flex_row_jstart">
                    <input type="checkbox" name="Yes" value="">
                    <label for="Yes">Yes</label>
                  </div>
                  <div class="flex_row_jstart">
                    <input type="checkbox" name="No" value="">
                    <label for="No">No</label>
                  </div>
                </div>
                <style media="screen">
                </style>
              </div>
              <div class="flex_column">
                <label for="Trance">Maximal trance <br>period (in months)</label>
                <div class="flex_column">
                  <input type="number" name="Trance" value="">
                </div>
              </div>
              <div class="flex_column">
                <label for="Trance">Posibility of daily <br>paypment (for rent type)?</label>
                <div class="flex_column">
                  <div class="flex_row_jstart">
                    <input type="checkbox" name="Yes" value="">
                    <label for="Yes">Yes</label>
                  </div>
                  <div class="flex_row_jstart">
                    <input type="checkbox" name="No" value="">
                    <label for="No">No</label>
                  </div>
                </div>
                <style media="screen">
                </style>
              </div>
              <div class="flex_column">
                <label for="Day">Price per day <br>(for rent)?</label>
                <div class="flex_row_jstart">
                  <input type="number" name="Day" value="">
                  <i class="fas fa-euro-sign"></i>
                </div>
              </div>
            </div>
          </div>


          <div class="flex_row_jstart" style="column-gap:5px;">
            <h2 style="color: #234dd4">Specifications</h2>
            <i style="color: #234dd4;" class="fas fa-chevron-down"></i>
          </div>

          <div class="spec-box" style="margin-left:10px;">
            <div class="flex_row_jstart wrap" style="align-items:flex-end;">
              <div class="flex_column">
                <label for="Author">Author of ad</label>
                <select class="" name="Author">
                  <option value="">Comercial agent</option>
                  <option value="">Developer</option>
                  <option value="">Private person</option>
                </select>
              </div>
              <div class="flex_column">
                <label for="Year">Year of building:</label>
                <input name = "Year" type="number" min="1900" max="2099" step="1" value="2016" />
              </div>

              <div class="flex_column">
                <label for="Condition">Condition of offer</label>
                <select class="" name="Condition">
                  <option value="">New home</option>
                  <option value="">Good conditionr</option>
                  <option value="">Needs renovating</option>
                </select>
              </div>
              <div class="flex_column">
                <label for="Nr_rooms">Nr. of rooms</label>
                <input type="number" name="Nr_rooms" value="">
              </div>
              <div class="flex_column">
                <label for="Floor">Floor</label>
                <input type="number" name="Floor" value="">
              </div>
              <div class="flex_column">
                <label for="Nr_of_floors">Nr. of floors</label>
                <input type="number" name="Nr_of_floors" value="">
              </div>
              <div class="flex_column">
                <label for="Total_area">Total area, m2</label>
                <input type="number" name="Total_area" value="">
              </div>
              <div class="flex_column">
                <label for="Height">Ceiling height, cm</label>
                <input type="number" name="Height" value="">
              </div>
              <div class="flex_column">
                <label for="Balcon">Number of Balconies</label>
                <input type="number" name="Balcon" value="">
              </div>
              <div class="flex_column">
                <label for="Parking">Parking space</label>
                <select class="" name="Parking">
                  <option value="">---</option>
                  <option value="">Open</option>
                  <option value="">Garage</option>
                  <option value="">Under the canopy</option>
                  <option value="">Underground</option>
                </select>
              </div>
            </div>
          </div>

          <div class="flex_row_jstart" style="column-gap:5px;">
            <h2 style="color: #234dd4">Aditionally</h2>
            <i style="color: #234dd4;" class="fas fa-chevron-down"></i>
          </div>

          <style media="screen">
            .spec-box > .flex_row_jstart > .flex_row_jstart {
              flex: 0 0 20%;
              margin-bottom: 10px;
            }

            input[name = "Equipied"] {
              width: 20px;
              height: 20px;
            }

          </style>
          <div class="spec-box" style="margin-left:10px;">
            <div class="flex_row_jstart wrap" style="align-items: flex-end;">
              <div class="flex_row_jstart">
                <input type="checkbox" name="Ready" value="">
                <label for="Ready">Ready to move in</label>
              </div>
              <div class="flex_row_jstart">
                <input type="checkbox" name="Separate" value="">
                <label for="Separate">Separate entrance</label>
              </div>
              <div class="flex_row_jstart">
                <input type="checkbox" name="Equipied" value="">
                <label for="Equipied">With household appliances</label>
              </div>
              <div class="flex_row_jstart">
                <input type="checkbox" name="Furnished" value="">
                <label for="Furnished">Furnished</label>
              </div>
              <div class="flex_row_jstart">
                <input type="checkbox" name="Autonomous" value="">
                <label for="Autonomous">Autonomous heating</label>
              </div>
              <div class="flex_row_jstart">
                <input type="checkbox" name="Conditioner" value="">
                <label for="Conditioner">Conditioner</label>
              </div>
              <div class="flex_row_jstart">
                <input type="checkbox" name="Armor" value="">
                <label for="Armor">Armored door</label>
              </div>
              <div class="flex_row_jstart">
                <input type="checkbox" name="Telephone" value="">
                <label for="Telephone">Telephone line</label>
              </div>
              <div class="flex_row_jstart">
                <input type="checkbox" name="Smart" value="">
                <label for="Smart">Smart Home system</label>
              </div>
              <div class="flex_row_jstart">
                <input type="checkbox" name="Intercom" value="">
                <label for="Intercom">Intercom</label>
              </div>
              <div class="flex_row_jstart">
                <input type="checkbox" name="Internet" value="">
                <label for="Internet">Internet</label>
              </div>
              <div class="flex_row_jstart">
                <input type="checkbox" name="Cable" value="">
                <label for="Cable">TV cable</label>
              </div>
              <div class="flex_row_jstart">
                <input type="checkbox" name="Alarm" value="">
                <label for="Alarm">Alarm system</label>
              </div>
              <div class="flex_row_jstart">
                <input type="checkbox" name="Video" value="">
                <label for="Video">Video surveillance</label>
              </div>
              <div class="flex_row_jstart">
                <input type="checkbox" name="Elevator" value="">
                <label for="Elevator">Elevator</label>
              </div>
              <div class="flex_row_jstart">
                <input type="checkbox" name="Child" value="">
                <label for="Child">Children's playground</label>
              </div>
            </div>
          </div>

          <div class="flex_row_jstart" style="column-gap:5px;">
            <h2 style="color: #234dd4">Address</h2>
            <i style="color: #234dd4;" class="fas fa-chevron-down"></i>
          </div>

          <div class="spec-box" style="margin-left: 10px;">
            <div class="flex_row_jstart" style="align-items: flex-end;">
              <div class="flex_column">
                <label for="City">City</label>
                <select class="" name="City">
                  <option value="">Funchal</option>
                  <option value="">Machico</option>
                  <option value="">Santana</option>
                  <option value="">Camara de Lobos</option>
                  <option value="">Santa Cruz</option>
                  <option value="">Porto Moniz</option>
                  <option value="">Calheta</option>
                  <option value="">Ponto do Sol</option>
                  <option value="">Sao Vicente</option>
                  <option value="">Ribeira Brava</option>
                  <option value="">Vila Baleira</option>
                  <option value="">Ribeiro Frio</option>
                </select>
              </div>
              <div class="flex_column">
                <label for="Street">Street</label>
                <input type="text" name="Street" value="">
              </div>
              <div class="flex_column">
                <label for="street_nr">Nr. of street</label>
                <input type="text" name="street_nr" value="">
              </div>
            </div>
          </div>
          <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d5697.976885630815!2d26.065324655525252!3d44.43339928869624!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x40b201dbbe0b8639%3A0xeca7ba35fbc72d4d!2sCotroceni%20National%20Museum!5e0!3m2!1sen!2s!4v1619726043071!5m2!1sen!2s"  width="100%" height="450" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
          <div class="flex_row_jstart" style="column-gap:5px;">
            <h2 style="color: #234dd4">Photos</h2>
            <i style="color: #234dd4;" class="fas fa-chevron-down"></i>
          </div>

          <div class="spec-box" >
            <input type="file" name="Photos" value="">
          </div>

          <div class="flex_row_jstart" style="column-gap:5px;">
            <h2 style="color: #234dd4">Contacts</h2>
            <i style="color: #234dd4;" class="fas fa-chevron-down"></i>
          </div>

          <div class="spec-box" style="margin-left: 10px;">
            <div class="flex_row_jstart">
              <div class="flex_row_jstart">
                <label for="Name">Name: </label>
                <input type="email" name="Name" value="">
              </div>
              <div class="flex_row_jstart">
                <label for="Mobile">Mobile: </label>
                <input type="text" name="Mobile" value="">
              </div>
              <div class="flex_row_jstart">
                <label for="Mobile">Email: </label>
                <input type="email" name="Email" value="">
              </div>
            </div>
          </div>

        </div>
        <div class="button">
          <button type="submit" id= "contact_mail" name = "contact_mail">
            <i class="fas fa-paper-plane"></i>
            <p>Send</p>
          </button>
          <button type="submit" class = "reset">Reset</button>
        </div>
      </form>
    </section>
    <?php require_once('footer.php'); ?>
  </body>
</html>
<style media="screen">

  .filter h1 {
    display: flex;
    flex-wrap: wrap;
    flex-direction: column;
    flex: 1;
    align-items: center;
    justify-content: center;
    border-bottom: 1px solid;
    }

  .checkbox_main_div {
    display: flex;
    flex-direction: column;
    justify-content: flex-start;
    width: 100%;
  }

  .checbox_second_div {
    display: flex;
    flex-direction: row;
    justify-content: flex-start;
    column-gap: 5%;
    align-items: center;
  }

  input[type ="checkbox"], input[type='radio'] {
    height: 20px !important;
    width: 20px !important;
  }

  .spec-box > label, .flex_column > label {
    font-size: 18px !important;
    font-weight: bold;
    margin-bottom: 5px;
    margin-right: auto;

  }
    .filter {
      margin-top: 15px;
      margin-bottom: 15px;
      padding-top: 15px;
      padding-bottom: 15px;
      background: #ededed;
      box-shadow: rgba(0, 0, 0, 0.16) 0px 1px 4px;
    }

    .filter select, .filter input {
      padding: 10px;
      height: 50px;
      width: 100%;
    }

    .specifications {
      display: flex;
      flex-direction: row;
      flex-wrap: wrap;
      /* justify-content: space-between; */
      align-items: center;
    }

    .spec-box {
        width: 100%;
        display: flex;
        flex-direction: column;
        align-items: center;
        min-height: 70px;
        margin-bottom:20px;
    }
    /* .specifications {
      line-height: 40px;
    } */


    .button {
      display: flex;
      column-gap: 10px;
      justify-content: space-between;
    }

    .button > * {
      width: 30% !important;
    }

    .reset {
      background-color: red !important;
    }

    .filter select {
      border: none;
      background-color: #fff;
      border-radius: 0;
      border-width: 0;
    }

</style>
